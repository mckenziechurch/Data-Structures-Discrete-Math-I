package dsdm;

/**
 * MergeSort
 * 
 * @author CS3151
 * @version Spring 2023
 */
public class MergeSort {

	/**
	 * Sorts the specified array.
	 * 
	 * @param <T>      the type of the array lements
	 * @param elements the elements to be sorted
	 */
	public static <T> void sort(Comparable<T>[] elements) {
		sort(elements, 0, elements.length - 1);
	}

	/**
	 * Sorts the subarray of elements that starts at index low end ends at index
	 * high.
	 * 
	 * @param <T>      the type of the elements to be sorted element
	 * @param elements the array containing the subarray to be sorted
	 * @param low      the start index of the subarray
	 * @param high     the end index of the subarray
	 */
	private static <T> void sort(Comparable<T>[] elements, int low, int high) {
		if (low < high) {
			int mid = (low + high) / 2;
			sort(elements, low, mid);
			sort(elements, mid + 1, high);
			merge(elements, low, mid, high);
		}
	}

	/**
	 * Merges two sorted, consecutive subarray of elements into one sorted subarray.
	 * The first subarray starts at index low and ends at index mid. The second
	 * subarray starts at index mid + 1 and ends at index high.
	 * 
	 * @pre low <= mid <= high and elements[low,...,mid] and
	 *      elements[mid+1,...,high] are sorted
	 * @param <T>      the type of the elements to be merged
	 * @param elements the array containing the subarrays to be merged
	 * @param low      the start index of the first subarray
	 * @param mid      the end index of the first subarray
	 * @param high     the end index of the second subarray
	 */
	private static <T> void merge(Comparable<T>[] elements, int low, int mid, int high) {

	}

	/**
	 * Copies the elements of fromArray from index startFrom to index endFrom
	 * inclusively to the array toArray where the first copied element is placed at
	 * index startTo.
	 * 
	 * @param <T>       the type of the elements to be copied
	 * @param fromArray the array with the elements to be copied
	 * @param startFrom the index in fromArray of the first element to be copied
	 * @param endFrom   the index in fromArray of the last element to be copied
	 * @param toArray   the array to which the elements are copied
	 * @param startTo   the index in toArray to which the first element is copied
	 */
	private static <T> void copy(Comparable<T>[] fromArray, int startFrom, int endFrom, Comparable<T>[] toArray,
			int startTo) {
		for (int i = startFrom, j = startTo; i <= endFrom; i++, j++) {
			toArray[j] = fromArray[i];
		}
	}
}
