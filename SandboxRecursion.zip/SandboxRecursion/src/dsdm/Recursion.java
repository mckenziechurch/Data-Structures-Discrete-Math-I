package dsdm;

import java.util.Stack;

/**
 * Recursion
 * 
 * @author CS3151
 * @version Spring 2023
 */
public class Recursion {

	public static void main(String[] args) {
//		recursiveMethod();
//		indirectRecursion();
		
//		Stack<String> stack = new <String>Stack();
//		String item = "";
//		while (true) {
//			item += "hello";
//			stack.push(item);
//		}
	}

	public static void recursiveMethod() {
		recursiveMethod();
	}

	public static void indirectRecursion() {
		indirectRecursionA();
	}
	
	public static void indirectRecursionA() {
		indirectRecursionB();
	}
	
	public static void indirectRecursionB() {
		indirectRecursion();
	}
}
