package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import dsdm.MergeSort;

class MergeSortTest {
	
	@Test
	void testEmptyArray() {
		Integer[] values = new Integer[0];
		MergeSort.sort(values);
		assertEquals(0, values.length);
	}
	
	@Test
	void testOneElementArray() {
		Integer[] values = {24};
		MergeSort.sort(values);
		assertAll(() -> assertEquals(1, values.length), 
				() -> assertEquals(24, values[0]));
	}
	
	@Test
	void testTwoElementArraySorted() {
		Integer[] values = {24, 78};
		MergeSort.sort(values);
		assertAll(() -> assertEquals(2, values.length), 
				() -> assertEquals(24, values[0]),
				() -> assertEquals(78, values[1]));
	}
	
	@Test
	void testTwoElementArrayUnsorted() {
		Integer[] values = {78, 24};
		MergeSort.sort(values);
		assertAll(() -> assertEquals(2, values.length), 
				() -> assertEquals(24, values[0]),
				() -> assertEquals(78, values[1]));
	}
	
	@Test
	void testThreeElementArraySorted() {
		String[] values = {"cat", "dog", "mouse"};
		MergeSort.sort(values);
		assertAll(() -> assertEquals(3, values.length), 
				() -> assertEquals("cat", values[0]),
				() -> assertEquals("dog", values[1]),
				() -> assertEquals("mouse", values[2]));
	}
	
	@Test
	void testThreeElementArrayUnsorted() {
		String[] values = {"dog", "mouse", "cat"};
		MergeSort.sort(values);
		assertAll(() -> assertEquals(3, values.length), 
				() -> assertEquals("cat", values[0]),
				() -> assertEquals("dog", values[1]),
				() -> assertEquals("mouse", values[2]));
	}
	
	@Test
	void testSixRandomValues() {
		Integer[] values = {12, 7, 34, 29, 45, 18};
		MergeSort.sort(values);
		assertAll(() -> assertEquals(6, values.length),
				() -> assertEquals(7, values[0]),
				() -> assertEquals(12, values[1]),
				() -> assertEquals(18, values[2]),
				() -> assertEquals(29, values[3]),
				() -> assertEquals(34, values[4]),
				() -> assertEquals(45, values[5]));
	}
	
	@Test
	void testSevenRandomValues() {
		Integer[] values = {56, 12, 45, 34, 29, 18, 7};
		MergeSort.sort(values);
		assertAll(() -> assertEquals(7, values.length),
				() -> assertEquals(7, values[0]),
				() -> assertEquals(12, values[1]),
				() -> assertEquals(18, values[2]),
				() -> assertEquals(29, values[3]),
				() -> assertEquals(34, values[4]),
				() -> assertEquals(45, values[5]),
				() -> assertEquals(56, values[6]));
	}
	
	@Test
	void testDoubleValues() {
		Double[] values = {5.6, 1.2, 4.5, 3.4, 2.9, 1.8, 0.7};
		double delta = 0.00001;
		MergeSort.sort(values);
		assertAll(() -> assertEquals(7, values.length),
				() -> assertEquals(0.7, values[0], delta),
				() -> assertEquals(1.2, values[1], delta),
				() -> assertEquals(1.8, values[2], delta),
				() -> assertEquals(2.9, values[3], delta),
				() -> assertEquals(3.4, values[4], delta),
				() -> assertEquals(4.5, values[5], delta),
				() -> assertEquals(5.6, values[6], delta));
	}
}
