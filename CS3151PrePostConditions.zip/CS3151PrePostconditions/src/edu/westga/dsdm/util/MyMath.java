package edu.westga.dsdm.util;

/**
 * The class MyMath
 * 
 * @author CS3151
 * @version Spring 2023
 */
public class MyMath {
	private double root1;
	private double root2;
	private boolean result;

	/**
	 * Gets the first root.
	 *
	 * @pre none
	 * @post none
	 * 
	 * @return the first root
	 */
	public Double getRoot1() {
		return this.root1;
	}

	/**
	 * Gets the second root.
	 *
	 * @pre none
	 * @post none
	 * 
	 * @return the second root
	 */
	public Double getRoot2() {
		return this.root2;
	}

	/**
	 * Gets the result.
	 *
	 * @pre none
	 * @post none
	 * 
	 * @return the result
	 */
	public boolean getResult() {
		return this.result;
	}

	/**
	 * The method calculates the roots of the equation a2�x^2 + a1�x + a0 = 0. The
	 * resulting roots are stored in the fields root1 and root2 unless the equation
	 * has no real roots. Unless both roots are the same or the equation has no real
	 * roots, the fields root1 and root2 differ.
	 *
	 * @pre
	 * 
	 * @post
	 * 
	 * @param a2 the coefficient of x^2 in the quadratic equation
	 * @param a1 the coefficient of x^1 in the quadratic equation
	 * @param a0 the coefficient of x^0 in the quadratic equation
	 */
	public void setRoots(double a2, double a1, double a0) {

	}

	/**
	 * Check for right angle. The method sets the field result to true if and only
	 * if the specified values l1, l2, and l3 could be the lengths of
	 * the sides of a right-angled triangle. A length should be a positive value.
	 * 
	 * @pre
	 * 
	 * @post
	 * 
	 * @param l1 the first length of a side of a triangle
	 * @param l2 the second length of a side of a triangle
	 * @param l3 the third length of a side of a triangle
	 */
	public void checkForRightAngle(double l1, double l2, double l3) {

	}
}
